library(testthat)
library(bizdays)

test_check("bizdays")
